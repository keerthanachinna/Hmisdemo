import { MbscFormOptions } from './forms';
import { FormControl } from './form-control';

export class Radio extends FormControl {
    constructor(element: any, settings: MbscFormOptions);
}